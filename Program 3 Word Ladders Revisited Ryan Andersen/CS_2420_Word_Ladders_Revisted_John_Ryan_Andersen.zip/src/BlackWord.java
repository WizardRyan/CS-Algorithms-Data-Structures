public class BlackWord {
    public int whenUsed;
    public String word;

    BlackWord(String word, int whenUsed){
        this.whenUsed = whenUsed;
        this.word = word;
    }
}
