public class Task2 extends Task{
    public Task2(int ID, int start, int deadline, int duration) {
        super(ID,start,deadline,duration);
    }

    // Start time then deadline if tie
    @Override
    public int compareTo(Task t2) {
        int comp = start - t2.start;
        if(comp == 0){
            return deadline-t2.deadline;
        }
        else{
            return comp;
        }
    }

}
